from __future__ import annotations

import html
import hmac
import json
import math
import os
import sqlite3
import threading
import time
import webbrowser
from datetime import date, datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "data" / "gestao.db"
WEB_PATH = ROOT / "web"
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
APP_USERNAME = os.getenv("APP_USERNAME", "admin")
APP_PASSWORD = os.getenv("APP_PASSWORD", "")
HOST = os.getenv("HOST", "0.0.0.0" if os.getenv("PORT") else "127.0.0.1")
PORT = int(os.getenv("PORT", "8765"))


def optional_amount(value):
    if value is None or value == "":
        return None
    amount = float(value)
    if not math.isfinite(amount) or amount < 0:
        raise ValueError("Valor deve ser um número não negativo.")
    return amount


def valid_month(value):
    value = str(value)
    parsed = datetime.strptime(value, "%Y-%m")
    if parsed.strftime("%Y-%m") != value:
        raise ValueError("Competência inválida.")
    return value


class PostgresConnection:
    def __init__(self, connection):
        self.connection = connection

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        try:
            if exc_type is None:
                self.connection.commit()
            else:
                self.connection.rollback()
        finally:
            self.connection.close()

    def execute(self, query, params=()):
        return self.connection.execute(query.replace("?", "%s"), params)

    def executescript(self, script):
        for statement in script.split(";"):
            if statement.strip():
                self.execute(statement)


def connect():
    if DATABASE_URL:
        try:
            import psycopg
            from psycopg.rows import dict_row
        except ImportError as exc:
            raise RuntimeError("Instale as dependências do arquivo requirements.txt.") from exc
        return PostgresConnection(psycopg.connect(DATABASE_URL, row_factory=dict_row))
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialize():
    if DATABASE_URL:
        with connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS students (
                    id BIGSERIAL PRIMARY KEY,
                    name TEXT NOT NULL,
                    phone TEXT DEFAULT '',
                    monthly_fee DOUBLE PRECISION,
                    active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS payments (
                    id BIGSERIAL PRIMARY KEY,
                    student_id BIGINT NOT NULL REFERENCES students(id),
                    month TEXT NOT NULL,
                    amount DOUBLE PRECISION,
                    status TEXT NOT NULL DEFAULT 'a_marcar'
                        CHECK(status IN ('a_marcar','pago','pendente','isento')),
                    paid_at TEXT,
                    note TEXT DEFAULT '',
                    UNIQUE(student_id, month)
                );
                CREATE TABLE IF NOT EXISTS demands (
                    id BIGSERIAL PRIMARY KEY,
                    title TEXT NOT NULL,
                    category TEXT NOT NULL DEFAULT 'Pessoal',
                    amount DOUBLE PRECISION,
                    due_date TEXT,
                    status TEXT NOT NULL DEFAULT 'aberta'
                        CHECK(status IN ('aberta','concluida')),
                    note TEXT DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
            """)
        return
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT DEFAULT '',
                monthly_fee REAL,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL REFERENCES students(id),
                month TEXT NOT NULL,
                amount REAL,
                status TEXT NOT NULL DEFAULT 'a_marcar'
                    CHECK(status IN ('a_marcar','pago','pendente','isento')),
                paid_at TEXT,
                note TEXT DEFAULT '',
                UNIQUE(student_id, month)
            );
            CREATE TABLE IF NOT EXISTS demands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'Pessoal',
                amount REAL,
                due_date TEXT,
                status TEXT NOT NULL DEFAULT 'aberta'
                    CHECK(status IN ('aberta','concluida')),
                note TEXT DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
        """)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_PATH), **kwargs)

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def session_signature(self, expires_at):
        message = f"{APP_USERNAME}:{expires_at}".encode("utf-8")
        return hmac.new(APP_PASSWORD.encode("utf-8"), message, "sha256").hexdigest()

    def is_authenticated(self):
        if not APP_PASSWORD:
            return True
        token = ""
        for item in self.headers.get("Cookie", "").split(";"):
            name, separator, value = item.strip().partition("=")
            if separator and name == "pilates_session":
                token = value
                break
        try:
            expires_text, signature = token.split(".", 1)
            expires_at = int(expires_text)
        except (ValueError, TypeError):
            return False
        return expires_at > int(time.time()) and hmac.compare_digest(
            signature, self.session_signature(expires_at)
        )

    def send_login_page(self, error=""):
        message = f'<p class="error">{html.escape(error)}</p>' if error else ""
        username = html.escape(APP_USERNAME, quote=True)
        body = f'''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Entrar | Ateliê Gestão Pilates</title>
<style>
*{{box-sizing:border-box}}body{{margin:0;min-height:100vh;display:grid;place-items:center;background:#f3f6f4;color:#183b32;font:16px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;padding:24px}}
main{{width:min(100%,420px);background:#fff;border:1px solid #e0e8e3;border-radius:20px;padding:36px;box-shadow:0 18px 55px #183b3212}}
.brand{{color:#467b68;font-size:13px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}}h1{{font-family:Georgia,serif;font-size:32px;line-height:1.1;margin:12px 0 8px}}.sub{{color:#62756d;margin:0 0 26px}}
label{{display:block;font-size:13px;font-weight:650;margin:16px 0 7px}}input{{width:100%;height:46px;border:1px solid #d5dfd9;border-radius:10px;padding:0 13px;font:inherit;color:#183b32}}input:focus{{outline:3px solid #b9d8ca;border-color:#467b68}}
button{{width:100%;height:48px;margin-top:22px;border:0;border-radius:10px;background:#185443;color:#fff;font:inherit;font-weight:700;cursor:pointer}}button:hover{{background:#103f33}}.error{{background:#fff1ef;color:#a43c32;border-radius:9px;padding:10px 12px;font-size:14px}}
</style></head><body><main><div class="brand">Ateliê Gestão Pilates</div><h1>Acessar painel</h1><p class="sub">Entre com suas credenciais para acompanhar alunos e mensalidades.</p>{message}
<form method="post" action="/login"><label for="username">Usuário</label><input id="username" name="username" value="{username}" autocomplete="username" required>
<label for="password">Senha</label><input id="password" name="password" type="password" autocomplete="current-password" required autofocus>
<button type="submit">Entrar</button></form></main></body></html>'''
        encoded = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'")
        self.end_headers()
        self.wfile.write(encoded)

    def require_auth(self):
        if self.is_authenticated():
            return True
        self.send_json({"error": "Faça login para continuar."}, 401)
        return False

    def send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/healthz":
            return self.send_json({"ok": True})
        if parsed.path == "/login":
            return self.send_login_page()
        if not self.is_authenticated():
            if parsed.path.startswith("/api/"):
                return self.send_json({"error": "Faça login para continuar."}, 401)
            return self.send_login_page()
        if not parsed.path.startswith("/api/"):
            if parsed.path == "/":
                self.path = "/index.html"
            return super().do_GET()
        query = parse_qs(parsed.query)
        month = query.get("month", [date.today().strftime("%Y-%m")])[0]
        with connect() as db:
            if parsed.path == "/api/dashboard":
                counts = {r["status"]: r["count"] for r in db.execute(
                    "SELECT p.status, COUNT(*) count FROM payments p JOIN students s ON s.id=p.student_id WHERE p.month=? AND s.active=1 GROUP BY p.status", (month,))}
                students = db.execute("SELECT COUNT(*) AS value FROM students WHERE active=1").fetchone()["value"]
                money = db.execute("""SELECT
                    SUM(CASE WHEN p.status='pago' THEN COALESCE(p.amount,s.monthly_fee,0) ELSE 0 END) received,
                    SUM(CASE WHEN COALESCE(p.status,'pendente')<>'pago' THEN COALESCE(p.amount,s.monthly_fee,0) ELSE 0 END) to_receive,
                    SUM(CASE WHEN p.status='pago' AND COALESCE(p.amount,s.monthly_fee) IS NULL THEN 1 ELSE 0 END) received_missing,
                    SUM(CASE WHEN COALESCE(p.status,'pendente')<>'pago' AND COALESCE(p.amount,s.monthly_fee) IS NULL THEN 1 ELSE 0 END) pending_missing
                    FROM students s LEFT JOIN payments p ON p.student_id=s.id AND p.month=? WHERE s.active=1""", (month,)).fetchone()
                open_demands = db.execute("SELECT COUNT(*) AS value FROM demands WHERE status='aberta'").fetchone()["value"]
                demand_total = db.execute("SELECT SUM(amount) AS value FROM demands WHERE status='aberta'").fetchone()["value"] or 0
                self.send_json({"month": month, "students": students,
                    "paid": counts.get("pago", 0), "pending": max(0, students - counts.get("pago", 0)),
                    "unmarked": 0, "exempt": 0,
                    "received": money["received"] or 0, "to_receive": money["to_receive"] or 0,
                    "received_missing": money["received_missing"] or 0, "pending_missing": money["pending_missing"] or 0,
                    "open_demands": open_demands, "demand_total": demand_total})
                return
            if parsed.path == "/api/students":
                include_inactive = query.get("all", ["0"])[0] == "1"
                sql = """SELECT s.id,s.name,s.phone,s.monthly_fee,s.active,
                    CASE WHEN p.status='pago' THEN 'pago' ELSE 'pendente' END payment_status,p.amount,p.paid_at,p.note
                    FROM students s LEFT JOIN payments p ON p.student_id=s.id AND p.month=?"""
                if not include_inactive:
                    sql += " WHERE s.active=1"
                sql += " ORDER BY LOWER(s.name)"
                rows = [dict(r) for r in db.execute(sql, (month,))]
                self.send_json(rows)
                return
            if parsed.path == "/api/arrears":
                today = date.today().isoformat()
                overdue_clause = ("CAST(p.month || '-10' AS DATE) < CAST(? AS DATE)"
                    if DATABASE_URL else "date(p.month || '-10') < date(?)")
                rows = [dict(r) for r in db.execute(f"""SELECT s.id student_id,s.name,s.phone,p.month,
                    COALESCE(p.amount,s.monthly_fee) amount,p.note
                    FROM payments p JOIN students s ON s.id=p.student_id
                    WHERE s.active=1 AND p.status<>'pago' AND {overdue_clause}
                    ORDER BY p.month ASC,LOWER(s.name)""", (today,))]
                self.send_json(rows)
                return
            if parsed.path == "/api/demands":
                rows = [dict(r) for r in db.execute("SELECT * FROM demands ORDER BY status, due_date IS NULL, due_date, id DESC")]
                self.send_json(rows)
                return
        self.send_json({"error": "Rota não encontrada."}, 404)

    def do_POST(self):
        if self.path == "/login":
            length = int(self.headers.get("Content-Length", "0"))
            if length > 8192:
                self.send_error(413)
                return
            fields = parse_qs(self.rfile.read(length).decode("utf-8", "replace"))
            username = fields.get("username", [""])[0]
            password = fields.get("password", [""])[0]
            if APP_PASSWORD and hmac.compare_digest(username, APP_USERNAME) and hmac.compare_digest(password, APP_PASSWORD):
                expires_at = int(time.time()) + 43200
                token = f"{expires_at}.{self.session_signature(expires_at)}"
                self.send_response(303)
                self.send_header("Location", "/")
                self.send_header("Set-Cookie", f"pilates_session={token}; Path=/; Max-Age=43200; HttpOnly; Secure; SameSite=Strict")
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                return
            self.send_login_page("Usuário ou senha incorretos.")
            return
        if not self.require_auth():
            return
        data = self.read_json()
        with connect() as db:
            if self.path == "/api/students":
                name = str(data.get("name", "")).strip()
                if not name:
                    return self.send_json({"error": "Informe o nome do aluno."}, 400)
                cur = db.execute("INSERT INTO students(name,phone,monthly_fee) VALUES(?,?,?) RETURNING id",
                    (name, str(data.get("phone", "")).strip(), data.get("monthly_fee") or None))
                return self.send_json({"id": cur.fetchone()["id"]}, 201)
            if self.path == "/api/payments/prepare-month":
                try:
                    month = valid_month(data.get("month", ""))
                except (TypeError, ValueError):
                    return self.send_json({"error": "Competência inválida."}, 400)
                insert_sql = ("""INSERT INTO payments(student_id,month,amount,status)
                    SELECT id,?,monthly_fee,'pendente' FROM students WHERE active=1
                    ON CONFLICT(student_id,month) DO NOTHING"""
                    if DATABASE_URL else
                    """INSERT OR IGNORE INTO payments(student_id,month,amount,status)
                    SELECT id,?,monthly_fee,'pendente' FROM students WHERE active=1""")
                db.execute(insert_sql, (month,))
                count = db.execute("SELECT COUNT(*) AS value FROM students WHERE active=1").fetchone()["value"]
                return self.send_json({"ok": True, "month": month, "count": count})
            if self.path == "/api/payments":
                try:
                    student_id = int(data["student_id"])
                    month = valid_month(data["month"])
                    amount = optional_amount(data.get("amount"))
                except (KeyError, TypeError, ValueError):
                    return self.send_json({"error": "Aluno, competência ou valor inválido."}, 400)
                status = str(data.get("status", "pendente"))
                if status not in ("pago", "pendente"):
                    return self.send_json({"error": "Status inválido."}, 400)
                exists = db.execute("SELECT 1 FROM students WHERE id=?", (student_id,)).fetchone()
                if not exists:
                    return self.send_json({"error": "Aluno não encontrado."}, 404)
                paid_at = (data.get("paid_at") or date.today().isoformat()) if status == "pago" else None
                if paid_at:
                    try:
                        datetime.strptime(paid_at, "%Y-%m-%d")
                    except ValueError:
                        return self.send_json({"error": "Data de pagamento inválida."}, 400)
                db.execute("""INSERT INTO payments(student_id,month,amount,status,paid_at,note)
                    VALUES(?,?,?,?,?,?) ON CONFLICT(student_id,month) DO UPDATE SET
                    amount=excluded.amount,status=excluded.status,paid_at=excluded.paid_at,note=excluded.note""",
                    (student_id, month, amount, status, paid_at, str(data.get("note", ""))))
                return self.send_json({"ok": True})
            if self.path == "/api/demands":
                title = str(data.get("title", "")).strip()
                if not title:
                    return self.send_json({"error": "Dê um nome à demanda."}, 400)
                cur = db.execute("INSERT INTO demands(title,category,amount,due_date,note) VALUES(?,?,?,?,?) RETURNING id",
                    (title, str(data.get("category", "Pessoal")), data.get("amount") or None,
                     data.get("due_date") or None, str(data.get("note", ""))))
                return self.send_json({"id": cur.fetchone()["id"]}, 201)
        self.send_json({"error": "Rota não encontrada."}, 404)

    def do_PATCH(self):
        if not self.require_auth():
            return
        data = self.read_json()
        parsed = urlparse(self.path)
        parts = parsed.path.strip("/").split("/")
        with connect() as db:
            if len(parts) == 3 and parts[:2] == ["api", "demands"]:
                demand_id = int(parts[2])
                db.execute("UPDATE demands SET status=? WHERE id=?",
                    ("concluida" if data.get("status") == "concluida" else "aberta", demand_id))
                return self.send_json({"ok": True})
            if len(parts) == 3 and parts[:2] == ["api", "students"]:
                student_id = int(parts[2])
                db.execute("UPDATE students SET name=?,phone=?,monthly_fee=? WHERE id=?",
                    (str(data.get("name", "")).strip(), str(data.get("phone", "")).strip(),
                     data.get("monthly_fee") or None, student_id))
                return self.send_json({"ok": True})
        self.send_json({"error": "Rota não encontrada."}, 404)

    def do_DELETE(self):
        if not self.require_auth():
            return
        parts = urlparse(self.path).path.strip("/").split("/")
        if len(parts) == 3 and parts[:2] == ["api", "students"]:
            with connect() as db:
                db.execute("UPDATE students SET active=0 WHERE id=?", (int(parts[2]),))
            return self.send_json({"ok": True})
        self.send_json({"error": "Rota não encontrada."}, 404)


def main():
    if os.getenv("RENDER") and not DATABASE_URL:
        raise RuntimeError("Configure DATABASE_URL para impedir gravação em disco temporário.")
    if (os.getenv("RENDER") or DATABASE_URL) and not APP_PASSWORD:
        raise RuntimeError("Configure APP_PASSWORD antes de publicar o painel.")
    initialize()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    url = f"http://{HOST}:{PORT}"
    print(f"Gestão Pilates aberta em {url}")
    if not os.getenv("RENDER"):
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
