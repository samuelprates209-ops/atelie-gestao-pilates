from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path
from urllib.parse import urlparse

from app import DATABASE_URL, connect, initialize

EXPECTED_PROJECT_REF = "igixswaqqvtsfvgzjwsk"
EXPECTED_REGION = "us-west-2"


def read_table(source, table, columns):
    return source.execute(f"SELECT {columns} FROM {table} ORDER BY id").fetchall()


def main():
    parser = argparse.ArgumentParser(
        description="Importa alunos e pagamentos do SQLite local para o projeto Supabase autorizado."
    )
    parser.add_argument(
        "--sqlite",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "data" / "gestao.db",
        help="Caminho do banco SQLite local",
    )
    parser.add_argument("--confirm-upload", action="store_true")
    parser.add_argument("--confirm-project-ref", default="")
    parser.add_argument("--confirm-region", default="")
    args = parser.parse_args()

    if not DATABASE_URL:
        raise SystemExit("Configure DATABASE_URL apenas no ambiente seguro do seu computador.")

    parsed_url = urlparse(DATABASE_URL)
    host = (parsed_url.hostname or "").lower()
    if "supabase" not in host:
        raise SystemExit("Destino recusado: este importador só aceita host Supabase.")
    project_ref = ""
    if host.startswith("db."):
        project_ref = host[3:].split(".", 1)[0]
    else:
        username = parsed_url.username or ""
        if username.startswith("postgres."):
            project_ref = username.split(".", 1)[1]
    if project_ref != EXPECTED_PROJECT_REF:
        raise SystemExit("Destino recusado: a conexão não aponta ao projeto Supabase autorizado.")
    if not args.sqlite.is_file():
        raise SystemExit(f"Banco local não encontrado: {args.sqlite}")
    if not (
        args.confirm_upload
        and args.confirm_project_ref == EXPECTED_PROJECT_REF
        and args.confirm_region == EXPECTED_REGION
    ):
        raise SystemExit(
            "Nenhum dado foi enviado. Confirme o destino com --confirm-upload "
            f"--confirm-project-ref {EXPECTED_PROJECT_REF} --confirm-region {EXPECTED_REGION}."
        )

    source = sqlite3.connect(args.sqlite)
    source.row_factory = sqlite3.Row
    try:
        students = read_table(source, "students", "id,name,phone,monthly_fee,active,created_at")
        payments = read_table(source, "payments", "id,student_id,month,amount,status,paid_at,note")
        demands_count = source.execute("SELECT COUNT(*) FROM demands").fetchone()[0]
        if demands_count:
            raise SystemExit(
                "A base contém demandas pessoais, fora do escopo aprovado nesta migração. "
                "Nenhum dado foi enviado."
            )
    finally:
        source.close()

    print(f"Destino Supabase: projeto {project_ref} | região West US (Oregon) ({EXPECTED_REGION})")
    print(f"Alunos: {len(students)} | Pagamentos: {len(payments)} | Demandas: 0")

    initialize()
    with connect() as db:
        destination_counts = {
            table: db.execute(f"SELECT COUNT(*) AS value FROM {table}").fetchone()["value"]
            for table in ("students", "payments", "demands")
        }
        if any(destination_counts.values()):
            raise SystemExit("O banco Supabase de destino não está vazio. Nenhum dado foi enviado.")
        for row in students:
            db.execute(
                """INSERT INTO students(id,name,phone,monthly_fee,active,created_at)
                VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                name=excluded.name,phone=excluded.phone,monthly_fee=excluded.monthly_fee,
                active=excluded.active,created_at=excluded.created_at""",
                tuple(row),
            )
        for row in payments:
            db.execute(
                """INSERT INTO payments(id,student_id,month,amount,status,paid_at,note)
                VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                student_id=excluded.student_id,month=excluded.month,amount=excluded.amount,
                status=excluded.status,paid_at=excluded.paid_at,note=excluded.note""",
                tuple(row),
            )
        for table in ("students", "payments", "demands"):
            db.execute(
                f"SELECT setval(pg_get_serial_sequence('{table}','id'), "
                f"COALESCE(MAX(id),1), COUNT(*) > 0) FROM {table}"
            )
    print(f"Importação concluída: {len(students)} alunos e {len(payments)} pagamentos.")
    print("Nenhum telefone ou nome foi exibido no terminal.")


if __name__ == "__main__":
    main()
