# Painel hospedado

Esta pasta contém somente o código do painel. Ela não inclui o banco `data/gestao.db` nem as cópias HTML exportadas com a lista de alunos.

## Serviços planejados

- Render Free: executa o painel Python; o serviço pode dormir após 15 minutos sem acessos.
- Supabase Free: PostgreSQL do projeto Ateliê Gestão Pilates, alocado pelo plano gratuito em West US (Oregon), região `us-west-2`.
- O disco local do Render é temporário. O painel exige `DATABASE_URL` e `APP_PASSWORD` no ambiente hospedado; cadastre as credenciais como secrets no painel do Render, nunca neste repositório.
- `APP_USERNAME` pode ser definido no Render; o padrão é `admin`.

## Publicação

1. Use o projeto Supabase `igixswaqqvtsfvgzjwsk` e mantenha a URI de conexão em segredo.
2. Publique somente o conteúdo desta pasta em um repositório privado.
3. Crie o serviço Render usando o Blueprint `render.yaml` e selecione o plano Free.
4. Cadastre `DATABASE_URL`, `APP_USERNAME` e uma senha forte `APP_PASSWORD` no ambiente do Render.
5. A aplicação cria as tabelas PostgreSQL ao iniciar. A base local não é enviada automaticamente.
6. A importação inicial exige confirmação explícita do projeto `igixswaqqvtsfvgzjwsk` e da região `us-west-2`, além de `--confirm-upload`. O importador recusa destinos diferentes e bancos que já contenham dados.

Não publique `data/gestao.db`, arquivos `.env`, senhas ou os HTMLs standalone com dados pessoais.
